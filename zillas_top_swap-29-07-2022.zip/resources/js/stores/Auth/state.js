export default {
    currentUser: JSON.parse(localStorage.getItem("currentUser")) || null,
};
